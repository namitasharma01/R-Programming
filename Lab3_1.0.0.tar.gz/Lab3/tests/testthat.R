library(testthat)
library(Lab3)

test_check("Lab3")
