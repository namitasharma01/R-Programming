## ----setup, eval=TRUE, include = FALSE-----------------------------------
library(Lab4)

knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- eval=TRUE----------------------------------------------------------
linreg_mod <- linreg$new(formula = Petal.Length ~ Species, data = iris)

## ---- eval=TRUE----------------------------------------------------------
linreg_mod$print()

## ---- eval=TRUE, warning=FALSE, fig.width=7------------------------------
linreg_mod$plot()

## ---- eval=TRUE----------------------------------------------------------
head(linreg_mod$resid())

## ---- eval=TRUE----------------------------------------------------------
head(linreg_mod$pred())

## ---- eval=TRUE----------------------------------------------------------
linreg_mod$coef()

## ---- eval=TRUE----------------------------------------------------------
linreg_mod$summary()

## ------------------------------------------------------------------------


