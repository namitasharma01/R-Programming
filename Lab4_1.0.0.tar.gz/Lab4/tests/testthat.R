library(testthat)
library(Lab4)

test_check("Lab4")
